import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/** Test case suite for Word Occurrences Application. */
@RunWith(Suite.class)
@SuiteClasses({ Test1.class, Test2.class, Test3.class })
public class AllTests {

}
